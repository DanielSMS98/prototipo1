'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const formapagoSchema = Schema ({
    mn: { type: Number, default:0 },
    dll: { type: Number, default:0 },
    tarjeta: { type: Number, default:0 },
    ventatotal: { type: Number, default:0 }

});

module.exports = mongoose.model('formapago', formapagoSchema)