'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const cortecajaSchema = Schema ({
    //usuario : { type: Schema.Types.ObjectId, ref: 'usuarios' },
    mn: { type: Number, default:0 },
    dll: { type: Number, default:0 },
    tarjeta: { type: Number, default:0 },
    ventatotal: { type: Number, default:0 }
})

module.exports = mongoose.model('Cortecaja', cortecajaSchema)
