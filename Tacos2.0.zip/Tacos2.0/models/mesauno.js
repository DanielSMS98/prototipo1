'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const mesaunoSchema = Schema ({
    mesa:{type: Number, default: 0},
    cantidad : { type: Number, default: 0},
    descripcion : String,
    preciou :{ type: Number, default: 0},
    preciot: { type: Number, default: 0},
    cobro: { type: Number, default: 0}
});

module.exports = mongoose.model('mesauno', mesaunoSchema)