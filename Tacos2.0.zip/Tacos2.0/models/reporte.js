'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const reporteSchema = Schema ({
    fecha: { type: Date},
    ventas : {type: Number, default:[0]}
});

module.exports = mongoose.model('reporte', reporteSchema)