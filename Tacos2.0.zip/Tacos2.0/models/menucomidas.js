'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const menucomidaSchema = Schema ({
    nombre : {type: String, unique: true},
    descripcion: String,
    precio : {type: Number, default:0}
})

module.exports = mongoose.model('menucomida', menucomidaSchema)
