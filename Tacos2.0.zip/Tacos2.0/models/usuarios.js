'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const usuariosSchema = Schema ({
    usuario : String,
    nombre: String,
    apellido: String,
    cargo: {type:String, enum:['mesero', 'cajero', 'taquero']},
    clave: String
})

module.exports = mongoose.model('Usuarios', usuariosSchema)
