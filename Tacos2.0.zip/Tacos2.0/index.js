'use strict'
const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const hbs = require('express-handlebars')
const app = express()
const handleBars = require('handlebars')

const Usuario = require('./models/usuarios')
const Productos =require('./models/productos')
const Comanda =require('./models/comandas')
const Cortecaja =require('./models/cortecaja')
const Comidas =require('./models/menucomidas')
const Mesauno =require('./models/mesauno')
const Formapago =require('./models/formapago')
const Reporte =require('./models/reporte')




const port = process.env.PORT || 3000;

const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')

app.engine('.hbs', hbs({
    defaultLayout: 'layout',
    handlebars: allowInsecurePrototypeAccess(handleBars),
    extname: '.hbs'
}))

const methodOverride = require('method-override')
app.use(methodOverride('_method'))

mongoose.set('useCreateIndex', true)

app.set('view engine', '.hbs')
app.use('/static', express.static('public'))
app.use(express.static(__dirname+'/public'));

app.use(bodyParser.urlencoded({extended : false}))
app.use(bodyParser.json())

app.get('/', (req,res) =>{

    res.render('login')
})

app.get('/verproductos', (req,res) =>{
    Productos.find({ }).lean().exec(function(error, productos){
        res.render('verproductos', {productos})
        })  
    })
app.get('/verusuarios', (req,res) =>{
    Usuario.find({ }).lean().exec(function(error, usuarios){
    res.render('verusuarios', {usuarios})
    })
})
app.get('/vercomida', (req,res) =>{
    Comidas.find({ }).lean().exec(function(error, comidas){
    res.render('vercomida', {comidas})
    })
})
app.get('/api/cuenta', (req,res) =>{
    Mesauno.find( { cantidad: { $gt: 0 }}).lean().exec(function(error, mesauno){
        res.render('cuenta', {mesauno})
    })
})
app.get('/registrate', (req,res) =>{
    res.render('registrate')
})
app.get('/editausuario', (req,res) =>{
    res.render('editausuario')
})
app.get('/inicio', (req,res) =>{
    res.render('inicio')
})
app.get('/inicio', (req,res) =>{
    res.render('inicio')
})
app.get('/backup', (req,res) =>{
    res.render('backup')
})
app.get('/catalogo', (req,res) =>{
    res.render('catalogo')
})
app.get('/menuproductos', (req,res) =>{
    res.render('menuproductos')
})
app.get('/prodnuevo', (req,res) =>{
    res.render('prodnuevo')
})
app.get('/menucomandas', (req,res) =>{
    res.render('menucomandas')
})
app.get('/editarprod', (req,res) =>{
    res.render('editarprod')
})
app.get('/editarcomida', (req,res) =>{
    res.render('editarcomida')
})
app.get('/menusuario', (req,res) =>{
    res.render('menusuario')
})
app.get('/cortecaja', (req,res) =>{
    res.render('cortecaja')
})
app.get('/cambio', (req,res) =>{
    res.render('cambio')
})
app.get('/mascomida', (req,res) =>{
    res.render('mascomida')
})
app.get('/admin', (req,res) =>{
    res.render('admin')
})
app.get('/api/pago', (req,res) =>{
    res.render('pago')
})
app.get('/vereporte', (req,res) =>{
    Reporte.find({ }).lean().exec(function(error, reportes){
        res.render('vereporte', {reportes})
        }) 
})
app.post('/api/buscar/cuenta', (req, res)=>{
    var cuenta = req.body.busca;
    //console.log(req.body.busca)
    Comanda.find({mesa: cuenta}).lean().exec(function(err, comanda){
        if(err) return res.status(500).send({
            message: `Error al realizar la peticion ${err}`
        });
        if (!comanda) return res.status(404).send({
            message: `El producto no existe`
        });
        res.render('pago', {comanda: comanda[0]});
    });
    
});

app.get('/api/pago/:cobro', (req,res) =>{
    var cobro = req.params.cobro
    Comanda.findOne({cobro: cobro}).lean().exec(function(err, comanda){
        if(err) return res.status(500).send({
            message: `Error al realizar la peticion ${err}`});
        if (!comanda) return res.status(404).send({
             message: `El producto no existe`});
        res.render('pago', {comanda});
        });          
    });
app.get('/vermesas', (req,res) =>{
    Comanda.find({ }).lean().exec(function(error, comandas){
        res.render('vermesas', {comandas})
        })  
})
app.post('/api/formapago', (req,res) =>{
    let fp = new Formapago()
    fp.mn= parseInt(req.body.mn)
    fp.dll= parseInt(req.body.dll)
    fp.tarjeta= parseInt(req.body.tarjeta)
    fp.ventatotal = parseFloat((parseFloat(req.body.mn) + (parseFloat(req.body.dll)*23.20)+parseFloat(req.body.tarjeta)))
    fp.save((err, formapagoStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})
    //res.status(200).send({product: productStored})
    }); 
    var re= [{
        fecha: Date,
        ventas: 3200
    },
    {
        fecha: Date,
        ventas: 3900
    },
    {
        fecha: Date,
        ventas: 4500
    },
    {
        fecha: Date,
        ventas: 3200
    },{
        fecha: Date,
        ventas: 4200
    }
]
Reporte.collection.insertMany(re, function (err, docs) {
    if (err){ 
        return console.error(err);
    } else {
        console.log("Multiple documents inserted to Collection");
        }
      });

    Comanda.find( { mesa: 1}).lean().exec(function(error, comanda){
    var a = parseFloat(req.body.mn)
    var b= (parseFloat(req.body.dll)*23.20)
    var c= parseFloat(req.body.tarjeta)
    var total = a+b+c
    var tl= comanda.cobro
    var cambio = (total - tl)
    res.render('cambio', {comanda:comanda[0], cambio})
    })
})
app.delete('/api/borra/:mesa', (req,res)=>{
    let mesa = req.params.mesa
      Mesauno.find({mesa: mesa},(err, mesauno)=>{
        if (err) res.status(500).send({message:`Error al borrar el producto ${err}`})
        Comanda.find({mesa:mesa ,cantidad: { $gt: 0 }})
        //mesauno.remove({mesa: mesa})(err => {
        //if (err) res.status(500).send({message:`Error al borrar el producto`})
            //res.status(200).send({message:`El producto ha sido eliminado`})
           res.render('cuenta',{mesa, mesauno});
       // });
    });
});

app.post('/api/registro', (req,res) =>{
    console.log('POST/api/registro')
    //console.log(req.body)
    //res.status(200).send({message: 'El comanda se a recibido})
    let usuario = new Usuario()
    usuario.usuario = req.body.usuario
    usuario.nombre     = req.body.nombre
    usuario.apellido = req.body.apellido
    usuario.cargo = (req.body.puesto).toLowerCase();
    usuario.clave = toString(req.body.clave)
        console.log(req.body)
    usuario.save((err, usuarioStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})

    //res.status(200).send({product: productStored})
    res.render('login')
    }); 
});
app.post('/api/comandas', (req,res) =>{
    //console.log('POST/api/registro')
    console.log(req.body)
    let comanda = new Comanda()
    comanda.nombre = req.body.nombre
    comanda.codigo = req.body.codigo
    comanda.precio = parseInt(req.body.precio)
        console.log(req.body)
    comanda.save((err, comandaStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})

    //res.status(200).send({product: productStored})
    res.render('inicio')
    }); 
});
app.get('/api/producto/:productId',(req,res)=>{
    let productId = req.params.productId
    Productos.findById(productId,(err,productos) =>{
    // Product.find({price:productId},(err,todook)=>{
    if(err) return res.status(500).send({message:`Error al realizar la peticion${err}`})
    if(!productos) return res.status(404).send({message:`El comanda no existe`})
    //res.status(200).send({product:todook})
    //res.status(200).send({product:products})
        res.render('editarprod', {productos})
        });
    });
    app.post('/api/productos', (req,res) =>{
        var accion = req.body.accion
        console.log(req.body)
        let producto = new Productos()
        producto.nombre = req.body.nombre
        producto.codigo = req.body.codigo
        producto.precio = parseInt(req.body.precio)
            console.log(req.body)
        producto.save((err, comandaStored) =>{
            if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})
    
        //res.status(200).send({product: productStored})
        res.render('confirmaprod',{accion})
        }); 
    });
    app.put('/api/producto/:productId',(req,res)=>{
        let accion = req.body.accion;
        let productId = req.params.productId
        console.log(`El producto es: ${productId}`)
    
        let update = req.body
        console.log(update)
            Productos.findOneAndUpdate({_id:productId},update, (err, productos)=>{
                if (err) res.status(500).send({message:`Error al actualzar el producto ${err}`})
                res.render('confirmaprod',{accion});
            });
    });
app.delete('/api/producto/:productId', (req,res)=>{
        let productId = req.params.productId;
        let accion = req.body.accion;
        Productos.findById(productId,(err, productos)=>{
            if (err) res.status(500).send({message:`Error al borrar el producto ${err}`})
    
            productos.remove(err => {
                if (err) res.status(500).send({message:`Error al borrar el comanda`})
                //res.status(200).send({message:`El comanda ha sido eliminado`})
                res.render('confirmaprod', {accion});
            });
    });
});
app.get('/api/comida/:comidaid',(req,res)=>{
    let comidaid = req.params.comidaid
    Comidas.findById(comidaid,(err,comidas) =>{
    // Product.find({price:productId},(err,todook)=>{
    if(err) return res.status(500).send({message:`Error al realizar la peticion${err}`})
    if(!comidas) return res.status(404).send({message:`El comanda no existe`})
    //res.status(200).send({product:todook})
    //res.status(200).send({product:products})
        res.render('editarcomida', {comidas})
        });
    });
app.put('/api/comida/:comidaid',(req,res)=>{
    let accion = req.body.accion;
    let comidaid = req.params.comidaid
    console.log(`El producto es: ${comidaid}`)

    let update = req.body
    console.log(update)
        Comidas.findOneAndUpdate({_id:comidaid},update, (err, comidas)=>{
            if (err) res.status(500).send({message:`Error al actualzar el producto ${err}`})
            res.render('admin');
        });
});
app.delete('/api/comida/:comidaId', (req,res)=>{
    let comidaId = req.params.comidaId;
    let accion = req.body.accion;
    Comidas.findById(comidaId,(err, comidas)=>{
        if (err) res.status(500).send({message:`Error al borrar el producto ${err}`})

        comidas.remove(err => {
            if (err) res.status(500).send({message:`Error al borrar el comanda`})
            //res.status(200).send({message:`El comanda ha sido eliminado`})
            res.render('confirmaprod', {accion});
        });
});
});
app.get("/cortecaja", function(req, res) {
    Cortecaja.find({}, function(err, cortecaja) {
        res.status(200).send(cortecaja)
    });
});
app.post('/api/cortecaja', (req,res) =>{
    console.log('POST/api/cortecaja')
    var a = (parseInt(req.body.veinte)*20)
    var b = (parseInt(req.body.cincuenta)*50)
    var c = (parseInt(req.body.cien)*100)
    var d = (parseInt(req.body.docientos)*200)
    var e = (parseInt(req.body.quinientos)*500)
    var f = parseInt(req.body.monedas)
    var mn = a+b+c+d+e+f 
    var g = parseInt(req.body.und)
    var h = (parseInt(req.body.cincod)*5)
    var i = (parseInt(req.body.diezd)*10)
    var j = (parseInt(req.body.veinted)*20)
    var k = (parseInt(req.body.cincuentad)*50)
    var l = (parseInt(req.body.ciend)*100)
    var dll = g+h+i+j+k+l


    let cortecaja = new Cortecaja()
    cortecaja.usuario = req.body.cortecaja
    cortecaja.mn  = mn
    cortecaja.dll = dll
    cortecaja.tarjeta = parseInt(req.body.tarjeta)
    cortecaja.ventatotal = mn+dll
        console.log(req.body)
    cortecaja.save((err, cortecajaStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})

    //res.status(200).send({product: productStored})
    res.render('login')
    }); 
});
app.post('/api/pedido', (req,res) =>{
    var mesa= parseInt(req.body.options)
    
    if (parseInt(req.body.taconormal) > 0){
        var a=  (parseInt(req.body.taconormal))*25;
    }
    else{ var a = 0;}
    if (parseInt(req.body.tacondorado) > 0){
        var b=  (parseInt(req.body.tacodorado))*25;
    }
    else{ var b = 0;}
    if (parseInt(req.body.quesa) > 0){
        var c=  (parseInt(req.body.quesa))*35;
    }
    else{ var c = 0;}
    if (parseInt(req.body.consomecarne) > 0){
        var d=  (parseInt(req.body.consomecarne))*30;
    }
    else{ var d = 0;}
    if (parseInt(req.body.consome) > 0){
        var e=  (parseInt(req.body.consome))*18;
    }
    else{ var e = 0;}
    if (parseInt(req.body.orden) > 0){
        var f=  (parseInt(req.body.orden))*70;
    }
    else{ var f = 0;}
    if (parseInt(req.body.coca) > 0){
        var g=  (parseInt(req.body.coca))*20;
    }
    else{ var g = 0;}
    if (parseInt(req.body.fanta) > 0){
        var h=  (parseInt(req.body.fanta))*20;
    }
    else{ var h = 0;}
    if (parseInt(req.body.fantafresa) > 0){
        var i=  (parseInt(req.body.fantafresa))*20;
    }
    else{ var i = 0;}
    if (parseInt(req.body.sprite) > 0){
        var j=  (parseInt(req.body.sprite))*20;
    }
    else{ var j = 0;}
    if (parseInt(req.body.jugo) > 0){
        var k=  (parseInt(req.body.jugo))*20;
    }
    else{ var k = 0;}
    if (parseInt(req.body.tea) > 0){
        var l=  (parseInt(req.body.tea))*20;
    }
    else{ var l = 0;}

    const total= (a+b+c+d+e+f+g+h+i+j+k+l);
      console.log(req.body)

      var uno = [{
        mesa: mesa,
        cantidad: parseInt(req.body.taconormal) ,
        descripcion: 'Taco normal',
        preciou: 25,
        preciot: a,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.tacodorado) ,
        descripcion: 'Taco dorado',
        preciou: 25,
        preciot: b,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.quesa) ,
        descripcion: 'Quesabirria',
        preciou: 35,
        preciot: c,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.consomecarne) ,
        descripcion: 'Consome con carne',
        preciou: 30,
        preciot: d,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.consome) ,
        descripcion: 'Consome clasico',
        preciou: 18,
        preciot: e,
    },  
    {
        mesa: mesa,
        cantidad: parseInt(req.body.orden) ,
        descripcion: 'Orden de birria',
        preciou: 70,
        preciot: f,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.coca) ,
        descripcion: 'Coca cola',
        preciou: 20,
        preciot: g,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.fanta) ,
        descripcion: 'Fanta naranja',
        preciou: 20,
        preciot: h,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.fantafresa) ,
        descripcion: 'Fanta fresa',
        preciou: 20,
        preciot: i,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.sprite) ,
        descripcion: 'Sprite',
        preciou: 20,
        preciot: j,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.jugo) ,
        descripcion: 'Jugo',
        preciou: 20,
        preciot: k,
    },
    {
        mesa: mesa,
        cantidad: parseInt(req.body.tea) ,
        descripcion: 'Fuze tea',
        preciou: 20,
        preciot: l,
        cobro: total
    }
]
    
        Mesauno.collection.insertMany(uno, function (err, docs) {
            if (err){ 
                return console.error(err);
            } else {
                console.log("Multiple documents inserted to Collection");
                }
              });
    let comanda= new Comanda()   
    comanda.mesa = mesa
    comanda.cobro = total
    comanda.save((err, comandaStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})

    })
    res.render ('confirma');        
});

app.post('/api/mascomida', (req,res) =>{
    console.log('POST/api/mascomida')
    //console.log(req.body)
    //res.status(200).send({message: 'El comanda se a recibido})
    let comida = new Comidas()
    comida.nombre = req.body.nombre
    comida.descripcion = req.body.descripcion
    comida.precio = parseInt(req.body.precio)
        console.log(req.body)
    comida.save((err, comidasStored) =>{
        if (err) res.status(500).send({message: `Error al guardar en BD ${err}`})

    //res.status(200).send({product: productStored})
    res.render('admin')
    }); 
});

app.get('/api/usuario/:uid', (req,res) =>{
    let uid = req.params.uid
    Usuario.findById(uid,(err,usuarios) =>{
    // Product.find({price:productId},(err,todook)=>{
    if(err) return res.status(500).send({message:`Error al realizar la peticion${err}`})
    if(!usuarios) return res.status(404).send({message:`El producto no existe`})
    //res.status(200).send({product:todook})
    //res.status(200).send({product:products})
        res.render('editausuario', {usuarios})
        });
});


mongoose.connect('mongodb://localhost:27017/tacos',{useNewUrlParser: true, useUnifiedTopology: true },(err,res)=>{
    if(err){
        return console.log(`Error al conectar la BD ${err}`)
    }
    console.log('Conexion a la BD exitosa')
    
    app.listen(port,() => {
        console.log(`Ejecutando en http://localhost:${port}`)
    });
    
});
